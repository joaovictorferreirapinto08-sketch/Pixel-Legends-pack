PIXEL LEGENDS CRAFT BLOCKER

Bloqueia por padrão:
- todos os crafts com recipe/result contendo pokelucky
- pixelmon:eject_button
- minecraft:dropper
- minecraft:dispenser

Compilar:
gradle clean build

Jar:
build\libs\PixelLegendsCraftBlocker-1.0.0.jar

Instalar:
1. Coloque o jar em plugins/
2. Pare o servidor com:
   stop
3. Ligue pelo painel.

Reload do plugin:
craftblocker reload
