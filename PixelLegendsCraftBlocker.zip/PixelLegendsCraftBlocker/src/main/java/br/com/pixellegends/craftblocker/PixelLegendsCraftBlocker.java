package br.com.pixellegends.craftblocker;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.ShapelessRecipe;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public final class PixelLegendsCraftBlocker extends JavaPlugin implements Listener {

    private List<String> blockedModids;
    private List<String> blockedItems;
    private List<String> blockedNameContains;
    private String blockedMessage;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();
        removeBlockedRecipes();
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("PixelLegendsCraftBlocker ligado.");
    }

    private void loadSettings() {
        reloadConfig();
        blockedModids = lowerList(getConfig().getStringList("blocked-modids"));
        blockedItems = lowerList(getConfig().getStringList("blocked-items"));
        blockedNameContains = lowerList(getConfig().getStringList("blocked-name-contains"));
        blockedMessage = color(getConfig().getString("messages.blocked", "&cEsse craft está bloqueado no servidor."));
    }

    private List<String> lowerList(List<String> input) {
        List<String> output = new ArrayList<String>();
        for (String value : input) {
            if (value != null) {
                output.add(value.toLowerCase(Locale.ROOT));
            }
        }
        return output;
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text);
    }

    private void removeBlockedRecipes() {
        int removed = 0;
        Iterator<Recipe> iterator = Bukkit.recipeIterator();

        while (iterator.hasNext()) {
            Recipe recipe = iterator.next();
            if (recipe == null) continue;

            if (isBlockedRecipe(recipe)) {
                try {
                    iterator.remove();
                    removed++;
                } catch (Throwable ignored) {
                    // Em híbrido, se não der para remover, o listener ainda bloqueia o craft.
                }
            }
        }

        getLogger().info("Receitas bloqueadas removidas/tentadas: " + removed);
    }

    private boolean isBlockedRecipe(Recipe recipe) {
        String recipeKey = getRecipeKey(recipe);
        String resultKey = getItemKey(recipe.getResult());
        String resultName = getItemText(recipe.getResult());

        return matchesBlocked(recipeKey) || matchesBlocked(resultKey) || matchesBlocked(resultName);
    }

    private boolean isBlockedItem(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return false;

        String key = getItemKey(item);
        String text = getItemText(item);
        return matchesBlocked(key) || matchesBlocked(text);
    }

    private boolean matchesBlocked(String text) {
        if (text == null) return false;
        String lower = text.toLowerCase(Locale.ROOT);

        for (String modid : blockedModids) {
            if (lower.startsWith(modid + ":") || lower.contains(modid + ":") || lower.contains(modid + "/")) {
                return true;
            }
        }

        for (String item : blockedItems) {
            if (lower.startsWith(item) || lower.contains(item)) {
                return true;
            }
        }

        for (String name : blockedNameContains) {
            if (lower.contains(name)) {
                return true;
            }
        }

        return false;
    }

    private String getRecipeKey(Recipe recipe) {
        try {
            if (recipe instanceof ShapedRecipe) {
                NamespacedKey key = ((ShapedRecipe) recipe).getKey();
                return key.getNamespace() + ":" + key.getKey();
            }
            if (recipe instanceof ShapelessRecipe) {
                NamespacedKey key = ((ShapelessRecipe) recipe).getKey();
                return key.getNamespace() + ":" + key.getKey();
            }
            Method getKey = recipe.getClass().getMethod("getKey");
            Object key = getKey.invoke(recipe);
            if (key != null) return key.toString();
        } catch (Throwable ignored) {
        }
        return "";
    }

    private String getItemKey(ItemStack item) {
        if (item == null) return "";
        StringBuilder builder = new StringBuilder();

        try {
            NamespacedKey key = item.getType().getKey();
            builder.append(key.getNamespace()).append(":").append(key.getKey()).append(" ");
        } catch (Throwable ignored) {
        }

        try {
            Object nms = asNmsCopy(item);
            Object nmsItem = call(nms, "getItem");
            Object registryName = call(nmsItem, "getRegistryName");
            if (registryName != null) builder.append(registryName.toString()).append(" ");
        } catch (Throwable ignored) {
        }

        try {
            builder.append(item.serialize().toString()).append(" ");
        } catch (Throwable ignored) {
        }

        try {
            Object nms = asNmsCopy(item);
            Object tag = call(nms, "getTag");
            if (tag != null) builder.append(tag.toString()).append(" ");
        } catch (Throwable ignored) {
        }

        return builder.toString();
    }

    private String getItemText(ItemStack item) {
        if (item == null) return "";
        StringBuilder builder = new StringBuilder();

        try {
            builder.append(item.getType().name()).append(" ");
        } catch (Throwable ignored) {
        }

        try {
            if (item.hasItemMeta() && item.getItemMeta() != null) {
                if (item.getItemMeta().hasDisplayName()) {
                    builder.append(ChatColor.stripColor(item.getItemMeta().getDisplayName())).append(" ");
                }
                if (item.getItemMeta().hasLore()) {
                    builder.append(item.getItemMeta().getLore().toString()).append(" ");
                }
            }
        } catch (Throwable ignored) {
        }

        try {
            builder.append(item.toString()).append(" ");
        } catch (Throwable ignored) {
        }

        return builder.toString();
    }

    @EventHandler
    public void onPrepareCraft(PrepareItemCraftEvent event) {
        if (event.getRecipe() == null) return;

        if (isBlockedRecipe(event.getRecipe()) || isBlockedItem(event.getRecipe().getResult())) {
            event.getInventory().setResult(null);
        }
    }

    @EventHandler
    public void onCraft(CraftItemEvent event) {
        ItemStack result = event.getRecipe() == null ? event.getCurrentItem() : event.getRecipe().getResult();

        if (isBlockedItem(result) || (event.getRecipe() != null && isBlockedRecipe(event.getRecipe()))) {
            event.setCancelled(true);
            event.setCurrentItem(null);
            if (event.getWhoClicked() != null) {
                event.getWhoClicked().sendMessage(blockedMessage);
            }
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Bukkit.getScheduler().runTaskLater(this, new Runnable() {
            @Override
            public void run() {
                removeBlockedRecipes();
            }
        }, 20L);
    }

    private Object asNmsCopy(ItemStack item) throws Exception {
        String version = Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
        Class<?> craftItemStack = Class.forName("org.bukkit.craftbukkit." + version + ".inventory.CraftItemStack");
        Method method = craftItemStack.getMethod("asNMSCopy", ItemStack.class);
        return method.invoke(null, item);
    }

    private Object call(Object target, String methodName, Object... args) throws Exception {
        Method method = null;
        for (Method candidate : target.getClass().getMethods()) {
            if (candidate.getName().equals(methodName) && candidate.getParameterTypes().length == args.length) {
                method = candidate;
                break;
            }
        }
        if (method == null) throw new NoSuchMethodException(methodName);
        method.setAccessible(true);
        return method.invoke(target, args);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("pixellegends.craftblocker.admin")) {
            sender.sendMessage("§cSem permissão.");
            return true;
        }

        loadSettings();
        removeBlockedRecipes();
        sender.sendMessage("§aPixelLegendsCraftBlocker recarregado.");
        return true;
    }
}
